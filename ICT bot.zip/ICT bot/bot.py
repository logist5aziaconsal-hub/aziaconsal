import asyncio
import logging
import os
import tempfile
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
from typing import Optional, Tuple, Dict, Any, List

import pandas as pd
import ccxt.async_support as ccxt
import mplfinance as mpf
import matplotlib.pyplot as plt
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.types import FSInputFile

# ====================== РАСШИРЕННЫЕ НАСТРОЙКИ ======================
load_dotenv()
plt.switch_backend('Agg')

# --- Основные ---
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
CHANNEL_ID = os.getenv('CHANNEL_ID')
LEVERAGE = 40
MIN_RR = 2.0
TOP_PAIRS_COUNT = 40
ATR_PERIOD = 14

# --- Асинхронность ---
CCXT_TIMEOUT = 15
MAX_CONCURRENT_SYMBOLS = 6

# --- Гибкие настройки стратегии ---
# Установите LOG_LEVEL в 'DEBUG', чтобы видеть, почему бот отбраковывает пары
LOG_LEVEL = 'INFO' # 'DEBUG' или 'INFO'

# --- Фильтры контекста (4H) ---
HTF_BIAS_LOOKBACK = 50
FVG_DISPLACEMENT_BODY_PCT = 0.35
FVG_DISPLACEMENT_ATR_PCT = 0.5
MIN_FVG_SIZE_PCT = 0.20

# --- Фильтры входа (15M) ---
ENABLE_DAILY_PD_FILTER = False
ENABLE_LIQUIDITY_SWEEP = True
LTF_SWEEP_LOOKBACK = 30
LTF_DISPLACEMENT_BODY_PCT = 0.40
MAX_STOP_RISK_PCT = 4.0

# --- Графики ---
CHART_MAX_WORKERS = 4
# =============================================================================

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    format='%(asctime)s | %(levelname)s | %(message)s'
)
logger = logging.getLogger(__name__)

# --- Инициализация ---
bot = Bot(token=TELEGRAM_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()
exchange = ccxt.binance({'enableRateLimit': True, 'options': {'defaultType': 'future'}})
chart_executor = ThreadPoolExecutor(max_workers=CHART_MAX_WORKERS)
stats = {'signals': 0, 'last_reset': datetime.now().date()}
last_signals: Dict[str, float] = {}

# --- Вспомогательные функции ---
async def ccxt_call_with_timeout(coro, description: str = ""):
    try:
        return await asyncio.wait_for(coro, timeout=CCXT_TIMEOUT)
    except asyncio.TimeoutError:
        logger.warning(f"CCXT timeout: {description}")
    except Exception as e:
        logger.error(f"CCXT error [{description}]: {e}")
    return None

async def safe_send_message(text: str):
    try:
        await bot.send_message(CHANNEL_ID, text)
    except Exception as e:
        logger.error(f"Telegram send_message error: {e}")

async def safe_send_photo(photo_path: str, caption: str):
    try:
        photo = FSInputFile(photo_path)
        await bot.send_photo(CHANNEL_ID, photo, caption=caption)
    except Exception as e:
        logger.error(f"Telegram send_photo error: {e}")

def calculate_atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> pd.Series:
    if {'h', 'l', 'c'}.issubset(df.columns):
        high, low, close = df['h'], df['l'], df['c']
    else:
        high, low, close = df['high'], df['low'], df['close']
    prev_close = close.shift(1)
    tr1 = (high - low).abs()
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.ewm(span=period, adjust=False).mean()
    return atr

async def get_pairs() -> List[str]:
    try:
        tickers = await ccxt_call_with_timeout(exchange.fetch_tickers(), "fetch_tickers")
        if not tickers:
            raise RuntimeError("tickers is None")
        
        pairs = [
            {'s': symbol, 'v': t.get('quoteVolume', 0)}
            for symbol, t in tickers.items()
            if symbol.endswith(':USDT') and t.get('quoteVolume', 0) > 50_000_000
        ]
        
        top_pairs = sorted(pairs, key=lambda x: x['v'], reverse=True)[:TOP_PAIRS_COUNT]
        return [p['s'] for p in top_pairs]
    except Exception as e:
        logger.error(f"Ошибка получения пар: {e}")
        return ['BTC/USDT:USDT', 'ETH/USDT:USDT', 'SOL/USDT:USDT']

def get_htf_pd_bias(df: pd.DataFrame) -> Optional[str]:
    if len(df) < HTF_BIAS_LOOKBACK:
        return None
    
    recent_df = df.tail(HTF_BIAS_LOOKBACK)
    hi = recent_df['h'].max()
    lo = recent_df['l'].min()
    
    mid = lo + (hi - lo) * 0.5
    price = df['c'].iloc[-1]
    
    if price < mid:
        return 'LONG'
    elif price > mid:
        return 'SHORT'
    return None

def find_4h_fvg_context(df: pd.DataFrame, symbol: str) -> Tuple[Optional[str], Optional[Tuple[float, float]]]:
    if len(df) < 60:
        return None, None
    
    df = df.copy()
    df['atr'] = calculate_atr(df[['h', 'l', 'c']], ATR_PERIOD)
    df['range'] = df['h'] - df['l']
    df['body'] = (df['c'] - df['o']).abs()
    last_price = df['c'].iloc[-1]

    for i in range(len(df) - 3, 5, -1):
        prev, curr, nxt = df.iloc[i - 1], df.iloc[i], df.iloc[i + 1]

        if pd.isna(curr['atr']) or curr['atr'] <= 0:
            continue

        if curr['body'] < curr['range'] * FVG_DISPLACEMENT_BODY_PCT:
            continue
        if curr['range'] < curr['atr'] * FVG_DISPLACEMENT_ATR_PCT:
            continue

        side, lo, hi = None, None, None
        if nxt['l'] > prev['h']:
            lo, hi, side = prev['h'], nxt['l'], 'LONG'
            if last_price < lo: continue
        elif nxt['h'] < prev['l']:
            lo, hi, side = nxt['h'], prev['l'], 'SHORT'
            if last_price > hi: continue
        else:
            continue

        mid = (hi + lo) / 2
        fvg_pct = (hi - lo) / mid * 100
        if fvg_pct < MIN_FVG_SIZE_PCT:
            continue
        
        logger.debug(f"[{symbol}] На 4H найден {side} FVG ({lo}, {hi})")
        return side, (lo, hi)

    logger.debug(f"[{symbol}] На 4H не найдено подходящих FVG")
    return None, None

async def get_context_4h(symbol: str) -> Tuple[Optional[str], Optional[Tuple[float, float]]]:
    ohlcv = await ccxt_call_with_timeout(
        exchange.fetch_ohlcv(symbol, '4h', limit=100),
        f"fetch_ohlcv 4h {symbol}"
    )
    if not ohlcv: return None, None
    
    df = pd.DataFrame(ohlcv, columns=['ts', 'o', 'h', 'l', 'c', 'v'])
    bias = get_htf_pd_bias(df)
    if not bias:
        logger.debug(f"[{symbol}] Не удалось определить 4H bias")
        return None, None
    
    logger.debug(f"[{symbol}] 4H bias: {bias}")
    side, zone = find_4h_fvg_context(df, symbol)
    if not side or not zone:
        return None, None

    if side != bias:
        logger.debug(f"[{symbol}] FVG-сайд ({side}) не совпадает с bias ({bias})")
        return None, None
        
    return side, zone

def analyze_15m_fvg_retest(df: pd.DataFrame, side: str, fvg_zone: Tuple[float, float], symbol: str) -> Optional[Dict[str, Any]]:
    if df is None or len(df) < 80: return None

    df = df.copy()
    lo_z, hi_z = min(fvg_zone), max(fvg_zone)
    fvg_mid = lo_z + (hi_z - lo_z) * 0.62

    df['range'] = df['h'] - df['l']
    df['body'] = (df['c'] - df['o']).abs()
    curr = df.iloc[-1]

    if not (curr['l'] <= hi_z and curr['h'] >= lo_z):
        logger.debug(f"[{symbol}] 15M: Цена не находится в 4H FVG зоне.")
        return None
    logger.debug(f"[{symbol}] 15M: Цена зашла в 4H FVG.")

    if ENABLE_LIQUIDITY_SWEEP:
        prev = df.iloc[-LTF_SWEEP_LOOKBACK-1:-1]
        if side == 'LONG' and curr['l'] > prev['l'].min():
            logger.debug(f"[{symbol}] 15M: Не было снятия ликвидности снизу.")
            return None
        if side == 'SHORT' and curr['h'] < prev['h'].max():
            logger.debug(f"[{symbol}] 15M: Не было снятия ликвидности сверху.")
            return None
        logger.debug(f"[{symbol}] 15M: Обнаружен сбор ликвидности.")

    if curr['body'] < curr['range'] * LTF_DISPLACEMENT_BODY_PCT:
        logger.debug(f"[{symbol}] 15M: Свеча входа не является импульсной (тело < {LTF_DISPLACEMENT_BODY_PCT*100}%).")
        return None
    if (side == 'LONG' and curr['c'] <= curr['o']) or \
       (side == 'SHORT' and curr['c'] >= curr['o']):
        logger.debug(f"[{symbol}] 15M: Неверный цвет свечи подтверждения.")
        return None
    logger.debug(f"[{symbol}] 15M: Найдена подтверждающая импульсная свеча.")
    
    entry = fvg_mid
    sl = lo_z if side == 'LONG' else hi_z
    risk = abs(entry - sl)
    if risk <= 0: return None

    if (risk / entry * 100) > MAX_STOP_RISK_PCT:
        logger.debug(f"[{symbol}] 15M: Слишком большой стоп-лосс (>{MAX_STOP_RISK_PCT}%).")
        return None

    tp_min = entry + risk * MIN_RR if side == 'LONG' else entry - risk * MIN_RR
    lookback_tp = 80
    swing = df['h'].iloc[-lookback_tp:].max() if side == 'LONG' else df['l'].iloc[-lookback_tp:].min()
    tp = swing if abs(swing - entry) > abs(tp_min - entry) else tp_min
    
    rr = abs(tp - entry) / risk
    if rr < MIN_RR:
        logger.debug(f"[{symbol}] 15M: Risk/Reward ({rr:.2f}) меньше минимального ({MIN_RR}).")
        return None

    roi = abs(tp - entry) / entry * LEVERAGE * 100
    fvg_size_pct = (hi_z - lo_z) / entry * 100
    prec = 5 if entry < 1 else 4 if entry < 10 else 3 if entry < 100 else 2
    
    return {
        'symbol': "", 'side': side, 'entry': round(entry, prec), 'stop': round(sl, prec),
        'tp': round(tp, prec), 'fvg': round(fvg_size_pct, 2), 'roi': round(roi, 1),
        'risk': round((risk / entry) * LEVERAGE * 100, 1), 'fvg_zone': (lo_z, hi_z),
        'rr': round(rr, 2),
    }

def is_premium_discount(df_daily: pd.DataFrame, price: float, side: str) -> bool:
    if len(df_daily) < 10: return True
    hi = df_daily['h'].max()
    lo = df_daily['l'].min()
    mid = lo + (hi - lo) * 0.5
    if side == 'LONG':
        return price <= mid
    else:
        return price >= mid

async def analyze(symbol: str) -> Tuple[Optional[Dict[str, Any]], Optional[List[Any]]]:
    try:
        side, zone = await get_context_4h(symbol)
        if not side or not zone:
            return None, None
        logger.debug(f"[{symbol}] Пройден 4H контекст: {side}, Зона: {zone}")

        ohlcv_15m = await ccxt_call_with_timeout(
            exchange.fetch_ohlcv(symbol, '15m', limit=120),
            f"fetch_ohlcv 15m {symbol}"
        )
        if not ohlcv_15m: return None, None
        df_15m = pd.DataFrame(ohlcv_15m, columns=['ts', 'o', 'h', 'l', 'c', 'v'])
        last_price = df_15m['c'].iloc[-1]

        if ENABLE_DAILY_PD_FILTER:
            ohlcv_1d = await ccxt_call_with_timeout(
                exchange.fetch_ohlcv(symbol, '1d', limit=20),
                f"fetch_ohlcv 1d {symbol}"
            )
            if not ohlcv_1d: return None, None
            df_1d = pd.DataFrame(ohlcv_1d, columns=['ts', 'o', 'h', 'l', 'c', 'v'])
            if not is_premium_discount(df_1d, last_price, side):
                logger.debug(f"[{symbol}] Отброшен: не прошел фильтр по дневному Premium/Discount.")
                return None, None
            logger.debug(f"[{symbol}] Пройден фильтр по дневному Premium/Discount.")
        
        res = analyze_15m_fvg_retest(df_15m, side, zone, symbol)
        if res is None:
            return None, None

        res['symbol'] = symbol
        return res, ohlcv_15m
    except Exception as e:
        logger.error(f"Критическая ошибка анализа {symbol}: {e}", exc_info=True)
        return None, None

def _create_chart_sync(df_data, symbol: str, side: str, entry: float, sl: float, tp: float, fvg_zone: Optional[Tuple[float, float]]) -> Optional[str]:
    try:
        df = pd.DataFrame(df_data, columns=['ts', 'open', 'high', 'low', 'close', 'volume'])
        df['ts'] = pd.to_datetime(df['ts'], unit='ms')
        df.set_index('ts', inplace=True)
        
        mc = mpf.make_marketcolors(up='#26a69a', down='#ef5350', edge='inherit', wick='inherit')
        s = mpf.make_mpf_style(base_mpl_style='seaborn-v0_8-whitegrid', marketcolors=mc)
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.png', prefix=f"chart_{symbol.replace('/', '_')}_") as tmp_file:
            path = tmp_file.name

        hlines_dict = dict(hlines=[entry, sl, tp], colors=['#2962ff', '#f44336', '#4caf50'], linestyle='--', linewidths=1.5)
        
        fill_between = None
        if fvg_zone:
            lo_z, hi_z = min(fvg_zone), max(fvg_zone)
            fill_between = dict(y1=lo_z, y2=hi_z, color='#fb8c00', alpha=0.08)

        mpf.plot(
            df.tail(90),
            type='candle', style=s, hlines=hlines_dict,
            title=f"\\n{symbol.split(':')[0]} | {side} | 15m",
            ylabel='Price', savefig=dict(fname=path, dpi=120, bbox_inches='tight'),
            fill_between=fill_between
        )
        plt.close('all')
        return path
    except Exception as e:
        logger.error(f"Sync chart error for {symbol}: {e}")
        return None

async def generate_chart(ohlcv_15m: List[Any], symbol: str, side: str, entry: float, sl: float, tp: float, fvg_zone: Optional[Tuple[float, float]] = None) -> Optional[str]:
    try:
        if not ohlcv_15m: return None
        loop = asyncio.get_running_loop()
        path = await loop.run_in_executor(chart_executor, _create_chart_sync, ohlcv_15m, symbol, side, entry, sl, tp, fvg_zone)
        return path
    except Exception as e:
        logger.error(f"Ошибка генерации графика {symbol}: {e}")
        return None
        
async def process_symbol(symbol: str, sem: asyncio.Semaphore): 
    async with sem:
        res, ohlcv_15m = await analyze(symbol)
        if not res or not ohlcv_15m:
            return

        side = res['side']
        key = f"{symbol}_{side}"
        now_ts = datetime.now(timezone.utc).timestamp()
        
        if key in last_signals and (now_ts - last_signals[key]) < 8 * 3600:
            logger.info(f"Сигнал {key} уже был недавно. Пропускаем.")
            return

        chart_path = await generate_chart(
            ohlcv_15m, symbol, res['side'], res['entry'], res['stop'], res['tp'], res['fvg_zone']
        )
        
        stats['signals'] += 1
        emoji = '🟢 LONG' if side == 'LONG' else '🔴 SHORT'
        msg = (
            f"⚡️ <b>IMBALANCE SETUP #{stats['signals']} | {symbol.split(':')[0]}</b>\n"
            f"Направление: <b>{emoji}</b>\n\n"
            f"📍 Вход: <code>{res['entry']}</code>\n"
            f"🛡 Стоп: <code>{res['stop']}</code>\n"
            f"🎯 Тейк: <code>{res['tp']}</code>\n\n"
            f"📊 RR: 1:{res['rr']} | FVG: {res['fvg']}%-4H\n"
            f"📉 Риск: -{res['risk']}% | 💰 ROI: +{res['roi']}%\n"
            f"⚙️ Плечо: x{LEVERAGE}"
        )
        
        try:
            if chart_path and os.path.exists(chart_path):
                await safe_send_photo(chart_path, msg)
            else:
                await safe_send_message(msg)
            
            last_signals[key] = now_ts
            logger.info(f"✅ Сигнал отправлен: {symbol} ({side})")
        finally:
            if chart_path and os.path.exists(chart_path):
                try:
                    os.remove(chart_path)
                except Exception as e:
                    logger.warning(f"Не удалось удалить файл {chart_path}: {e}")

async def worker():
    logger.info("Imbalance FVG bot started.")
    sem = asyncio.Semaphore(MAX_CONCURRENT_SYMBOLS)
    
    while True:
        try:
            today = datetime.now().date()
            if today > stats['last_reset']:
                stats['signals'] = 0
                stats['last_reset'] = today
                last_signals.clear()
                logger.info("Статистика сигналов сброшена на новый день.")

            now = datetime.now(timezone.utc)
            minutes_to_wait = 15 - (now.minute % 15)
            seconds_to_wait = minutes_to_wait * 60 - now.second + 10
            
            logger.info(f"Ожидание закрытия 15m свечи: {seconds_to_wait:.0f} секунд")
            await asyncio.sleep(seconds_to_wait)
            
            logger.info("Начало нового цикла анализа...")
            pairs = await get_pairs()
            logger.info(f"Анализ {len(pairs)} пар...")
            
            tasks = [process_symbol(symbol, sem) for symbol in pairs]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for res in results:
                if isinstance(res, Exception):
                    logger.error(f"Ошибка в задаче: {res}", exc_info=res)

            logger.info("Круг анализа завершён.")
            
        except Exception as e:
            logger.error(f"CRITICAL ERROR in worker: {e}", exc_info=True)
            await asyncio.sleep(60)

async def main():
    try:
        await worker()
    finally:
        try:
            await exchange.close()
        except: pass
        chart_executor.shutdown(wait=True)
        logger.info("Бот корректно остановлен, ресурсы освобождены.")

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Бот остановлен пользователем.")
