// ====================================
// TELEGRAM BOT API SERVER
// Скопируйте этот файл в отдельную папку
// ====================================

require('dotenv').config();
const express = require('express');
const TelegramBot = require('node-telegram-bot-api');
const cors = require('cors');

const app = express();
const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN);

// ====================================
// MIDDLEWARE
// ====================================

// Разрешаем запросы с любых доменов (можно ограничить конкретным доменом)
app.use(cors({
  origin: '*', // Замените на 'https://aziaconsal.by' для безопасности
  methods: ['POST', 'GET', 'OPTIONS'],
  credentials: true
}));

app.use(express.json());

// ====================================
// ROUTES
// ====================================

// Health check - проверка работоспособности
app.get('/', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Telegram Bot API Server is running',
    timestamp: new Date().toISOString()
  });
});

// Главный endpoint для приёма заявок
app.post('/api/send-message', async (req, res) => {
  try {
    const data = req.body;
    let message = '';

    // ====================================
    // ФОРМИРОВАНИЕ СООБЩЕНИЙ
    // ====================================

    switch (data.type) {
      // Расчёт стоимости
      case 'quote':
        message = `🚚 *ЗАЯВКА НА РАСЧЁТ СТОИМОСТИ*\n\n` +
          `👤 *Имя:* ${data.name}\n` +
          `📞 *Телефон:* ${data.phone}\n` +
          `📧 *Email:* ${data.email || 'не указан'}\n\n` +
          `📍 *Откуда:* ${data.from}\n` +
          `📍 *Куда:* ${data.to}\n` +
          `📦 *Тип груза:* ${data.cargo || 'не указан'}\n` +
          `⚖️ *Вес:* ${data.weight || 'не указан'} кг\n` +
          `📏 *Объём:* ${data.volume || 'не указан'} м³\n` +
          `📅 *Дата отправки:* ${data.date || 'не указана'}\n\n` +
          `💬 *Комментарий:*\n${data.message || 'нет'}`;
        break;

      // Обратный звонок
      case 'callback':
        message = `📞 *ЗАЯВКА НА ОБРАТНЫЙ ЗВОНОК*\n\n` +
          `👤 *Имя:* ${data.name}\n` +
          `📞 *Телефон:* ${data.phone}\n` +
          `⏰ *Удобное время:* ${data.time}`;
        break;

      // Контактная форма
      case 'contact':
        message = `✉️ *ОБРАЩЕНИЕ С САЙТА*\n\n` +
          `👤 *Имя:* ${data.name}\n` +
          `📞 *Телефон:* ${data.phone}\n` +
          `📧 *Email:* ${data.email || 'не указан'}\n\n` +
          `💬 *Сообщение:*\n${data.message || 'нет'}`;
        break;

      // Заявка от перевозчика
      case 'carrier':
        message = `🚛 *ЗАЯВКА ОТ ПЕРЕВОЗЧИКА*\n\n` +
          `🏢 *Компания:* ${data.company}\n` +
          `👤 *Контактное лицо:* ${data.contact}\n` +
          `📞 *Телефон:* ${data.phone}\n` +
          `📧 *Email:* ${data.email || 'не указан'}\n\n` +
          `🚚 *Тип транспорта:* ${data.vehicleType}\n` +
          `🔢 *Количество:* ${data.vehicleCount || 'не указано'}\n` +
          `🗺️ *Маршруты:* ${data.regions || 'не указаны'}\n\n` +
          `💬 *Дополнительная информация:*\n${data.additional || 'нет'}`;
        break;

      // Неизвестный тип заявки
      default:
        message = `📨 *НОВАЯ ЗАЯВКА*\n\n` +
          `*Тип:* ${data.type || 'не указан'}\n\n` +
          `*Данные:*\n\`\`\`\n${JSON.stringify(data, null, 2)}\n\`\`\``;
    }

    // ====================================
    // ОТПРАВКА В TELEGRAM
    // ====================================

    await bot.sendMessage(process.env.TELEGRAM_CHAT_ID, message, {
      parse_mode: 'Markdown'
    });

    console.log(`✅ Message sent successfully: ${data.type}`);
    
    res.json({ 
      success: true, 
      message: 'Message sent successfully',
      type: data.type
    });

  } catch (error) {
    console.error('❌ Error sending message:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// ====================================
// ERROR HANDLING
// ====================================

// 404 - Not Found
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Not Found',
    message: 'The requested endpoint does not exist'
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Global error:', err);
  res.status(500).json({ 
    error: 'Internal Server Error',
    message: err.message 
  });
});

// ====================================
// SERVER START
// ====================================

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log('');
  console.log('🚀 ===================================');
  console.log(`🤖 Telegram Bot API Server`);
  console.log(`📡 Running on port ${PORT}`);
  console.log(`🌐 URL: http://localhost:${PORT}`);
  console.log('🟢 Status: ONLINE');
  console.log('====================================');
  console.log('');
  console.log('📋 Available endpoints:');
  console.log(`   GET  / - Health check`);
  console.log(`   POST /api/send-message - Send message to Telegram`);
  console.log('');
  console.log('⚙️  Configuration:');
  console.log(`   Bot Token: ${process.env.TELEGRAM_BOT_TOKEN ? '✅ Set' : '❌ Missing'}`);
  console.log(`   Chat ID: ${process.env.TELEGRAM_CHAT_ID ? '✅ Set' : '❌ Missing'}`);
  console.log('');
  console.log('🔄 Waiting for requests...');
  console.log('');
});

// ====================================
// GRACEFUL SHUTDOWN
// ====================================

process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
  });
});

process.on('SIGINT', () => {
  console.log('\n👋 Shutting down gracefully...');
  process.exit(0);
});
