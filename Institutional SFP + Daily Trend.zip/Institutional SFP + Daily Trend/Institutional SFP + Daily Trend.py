import asyncio
import logging
import os
import tempfile
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Any, List, Optional, Tuple

import ccxt.async_support as ccxt
import matplotlib.pyplot as plt
import mplfinance as mpf
import pandas as pd
from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import FSInputFile
from dotenv import load_dotenv

# ====================== CONFIG ======================
load_dotenv()
plt.switch_backend('Agg')

TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
CHANNEL_ID = os.getenv('CHANNEL_ID')

LEVERAGE = 40
MIN_RR = 3.0
MIN_EXPECTED_ROI = 45.0

LOOKBACK_SFP = 48          # Часы назад для поиска ключевых high/low
TOP_PAIRS_COUNT = 60
MIN_24H_VOLUME = 30_000_000

ATR_PERIOD = 14
SL_ATR_MULT = 1.2

# Асинхронность и лимиты
CCXT_TIMEOUT = 15
MAX_CONCURRENT_SYMBOLS = 6
SLEEP_BETWEEN_SYMBOLS = 0.2
ROUND_SLEEP_SECONDS = 180

# Кэш bias
BIAS_CACHE_TTL_HOURS = 6

# Графики
CHART_MAX_WORKERS = 4

# ====================================================

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(message)s')
logger = logging.getLogger(__name__)

bot = Bot(token=TELEGRAM_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))

exchange = ccxt.binance({
    'enableRateLimit': True,
    'options': {'defaultType': 'future'},
})

chart_executor = ThreadPoolExecutor(max_workers=CHART_MAX_WORKERS)

# Анти-спам по сигналам
last_signals: Dict[str, float] = {}

# Кэш дневного bias
daily_bias_cache: Dict[str, Dict[str, Any]] = {}
stats = {'signals': 0, 'last_reset': datetime.now().date()}

# ====================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ======================

async def ccxt_call_with_timeout(coro, description: str = ""):
    try:
        return await asyncio.wait_for(coro, timeout=CCXT_TIMEOUT)
    except asyncio.TimeoutError:
        logger.warning(f"CCXT timeout: {description}")
    except ccxt.DDoSProtection as e:
        logger.warning(f"CCXT DDoS Protection: {description} | {e}")
    except ccxt.RateLimitExceeded as e:
        logger.warning(f"CCXT Rate Limit Exceeded: {description} | {e}")
    except ccxt.BadSymbol as e:
        logger.warning(f"CCXT BadSymbol (возможно delisted): {description} | {e}")
    except ccxt.NetworkError as e:
        logger.warning(f"CCXT NetworkError: {description} | {e}")
    except Exception as e:
        logger.error(f"Неизвестная CCXT ошибка [{description}]: {e}", exc_info=True)
    return None


async def safe_send_message(text: str):
    try:
        await bot.send_message(CHANNEL_ID, text)
    except Exception as e:
        logger.error(f"Telegram send_message error: {e}")


async def safe_send_photo(photo_path: str, caption: str):
    try:
        photo = FSInputFile(photo_path)
        await bot.send_photo(CHANNEL_ID, photo, caption=caption)
    except Exception as e:
        logger.error(f"Telegram send_photo error: {e}")

# ====================== ИНДИКАТОРЫ ======================

def calculate_atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> float:
    high = df['high']
    low = df['low']
    close = df['close']

    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)

    atr = tr.rolling(period).mean().iloc[-1]
    return float(atr) if pd.notna(atr) and atr > 0 else 0.0

# ====================== ДАННЫЕ ======================

async def get_top_pairs() -> List[str]:
    try:
        await exchange.load_markets()  # Важно! Загружаем рынки
        tickers = await ccxt_call_with_timeout(
            exchange.fetch_tickers(),
            description="fetch_tickers"
        )
        if not tickers:
            raise RuntimeError("tickers is None")

        pairs = []
        for symbol, ticker in tickers.items():
            market = exchange.markets.get(symbol)
            if not market:
                continue
            if market.get('swap') != True or not symbol.endswith('/USDT:USDT'):
                continue
            if not market.get('active'):
                continue

            vol = ticker.get('quoteVolume') or 0
            if vol >= MIN_24H_VOLUME:
                pairs.append((symbol, vol))

        pairs_sorted = sorted(pairs, key=lambda x: x[1], reverse=True)
        top_symbols = [p[0] for p in pairs_sorted[:TOP_PAIRS_COUNT]]
        logger.info(f"Топ-{len(top_symbols)} пар загружено")
        return top_symbols

    except Exception as e:
        logger.error(f"Ошибка получения топ пар: {e}")
        return ['BTC/USDT:USDT', 'ETH/USDT:USDT']


async def get_daily_bias(symbol: str) -> Optional[str]:
    now = datetime.now(timezone.utc)
    cached = daily_bias_cache.get(symbol)

    if cached and (now - cached['ts']) < timedelta(hours=BIAS_CACHE_TTL_HOURS):
        return cached['bias']

    market = exchange.market(symbol)
    ohlcv = await ccxt_call_with_timeout(
        exchange.fetch_ohlcv(market['id'], '1d', limit=210),
        description=f"fetch_ohlcv 1d {symbol}"
    )
    if not ohlcv or len(ohlcv) < 200:
        return None

    df = pd.DataFrame(ohlcv, columns=['ts', 'o', 'h', 'l', 'c', 'v'])
    ema200 = df['c'].ewm(span=200, adjust=False).mean().iloc[-1]
    close = df['c'].iloc[-1]

    bias = 'BULL' if close > ema200 else 'BEAR'
    daily_bias_cache[symbol] = {'bias': bias, 'ts': now}
    return bias

# ====================== СТРАТЕГИЯ (SFP) ======================

def detect_sfp_setup(df: pd.DataFrame, bias: str, atr: float) -> Optional[Dict[str, Any]]:
    if len(df) < LOOKBACK_SFP + 5:
        return None

    c = df.iloc[-1]
    prev = df.iloc[-LOOKBACK_SFP:-1]

    high_liq = prev['high'].max()
    low_liq = prev['low'].min()

    avg_vol = df['volume'].iloc[-20:].mean()
    if c['volume'] < avg_vol * 1.3:
        return None

    candle_range = c['high'] - c['low']
    body = abs(c['close'] - c['open'])
    if candle_range == 0 or body < candle_range * 0.3:
        return None

    if bias == 'BULL' and c['low'] < low_liq and c['close'] > low_liq:
        side = 'LONG'
        wick_size = c['close'] - c['low']
        tp_level = high_liq
    elif bias == 'BEAR' and c['high'] > high_liq and c['close'] < high_liq:
        side = 'SHORT'
        wick_size = c['high'] - c['close']
        tp_level = low_liq
    else:
        return None

    body_size = abs(c['close'] - c['open'])
    if wick_size < body_size * 1.2:
        return None

    wick_atr_ratio = wick_size / atr
    if wick_atr_ratio < 0.5 or wick_atr_ratio > 3:
        return None

    return_speed = wick_size / atr
    if return_speed < 0.7:
        return None

    entry = c['close']
    sl = c['low'] - atr * SL_ATR_MULT if side == 'LONG' else c['high'] + atr * SL_ATR_MULT
    tp = tp_level

    risk = abs(entry - sl)
    reward = abs(tp - entry)
    if risk <= 0 or reward <= 0:
        return None

    rr = reward / risk
    if rr < MIN_RR:
        return None

    roi = (reward / entry) * LEVERAGE * 100
    if roi < MIN_EXPECTED_ROI:
        return None

    prec = 5 if entry < 1 else 4 if entry < 10 else 3

    risk_pct = (risk / entry) * LEVERAGE * 100

    return {
        'side': side,
        'entry': round(entry, prec),
        'sl': round(sl, prec),
        'tp': round(tp, prec),
        'rr': round(rr, 2),
        'roi': round(roi, 1),
        'risk_pct': round(risk_pct, 1), # [НОВОЕ]
        'bias': bias,
    }

# ====================== АНАЛИЗ ======================

async def analyze(symbol: str) -> Tuple[Optional[Dict[str, Any]], Optional[List]]:
    try:
        market = exchange.market(symbol)
        market_id = market['id']

        ohlcv = await ccxt_call_with_timeout(
            exchange.fetch_ohlcv(market_id, '1h', limit=LOOKBACK_SFP + 10),
            description=f"fetch_ohlcv 1h {symbol}"
        )
        if not ohlcv or len(ohlcv) < LOOKBACK_SFP + 10:
            return None, None

        df = pd.DataFrame(ohlcv, columns=['ts', 'open', 'high', 'low', 'close', 'volume'])

        atr = calculate_atr(df[['high', 'low', 'close']])
        if atr <= 0:
            return None, None

        bias = await get_daily_bias(symbol)
        if bias not in ('BULL', 'BEAR'):
            return None, None

        setup = detect_sfp_setup(df, bias, atr)
        if not setup:
            return None, None

        setup['symbol'] = symbol.split(':')[0]
        return setup, ohlcv[-100:]  # последние 100 свечей для графика

    except Exception as e:
        logger.error(f"Analyze error {symbol}: {e}")
        return None, None

# ====================== ГРАФИКИ ======================

def _chart_sync(ohlcv, symbol: str, entry: float, sl: float, tp: float) -> Optional[str]:
    try:
        df = pd.DataFrame(ohlcv, columns=['ts', 'open', 'high', 'low', 'close', 'volume'])
        df['ts'] = pd.to_datetime(df['ts'], unit='ms')
        df.set_index('ts', inplace=True)

        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp:
            path = tmp.name

        mpf.plot(
            df,
            type='candle',
            style='charles',
            hlines=dict(hlines=[entry, sl, tp], colors=['#00e676', '#ff1744', '#2979ff'], linestyle='--', linewidths=1.2),
            title=f"INSTITUTIONAL SFP | {symbol.split(':')[0]}",
            savefig=dict(fname=path, dpi=140, bbox_inches='tight')
        )
        plt.close('all')
        return path
    except Exception as e:
        logger.error(f"Sync chart error: {e}")
        return None


async def generate_chart(ohlcv: List, symbol: str, entry: float, sl: float, tp: float) -> Optional[str]:
    try:
        loop = asyncio.get_running_loop()
        path = await loop.run_in_executor(
            chart_executor,
            _chart_sync,
            ohlcv, symbol, entry, sl, tp
        )
        return path
    except Exception as e:
        logger.error(f"Ошибка генерации графика {symbol}: {e}")
        return None

# ====================== ОБРАБОТКА ======================

async def process_symbol(symbol: str, sem: asyncio.Semaphore):
    async with sem:
        setup, ohlcv_chart = await analyze(symbol)
        if not setup or not ohlcv_chart:
            return

        side = setup['side']
        key = f"{symbol}_{side}"
        now_ts = datetime.now(timezone.utc).timestamp()
        
        if last_signals.get(key) and (now_ts - last_signals[key]) < 7200:
            return
            
        last_signals[key] = now_ts

        # [ИЗМЕНЕНО] Полностью новый блок формирования сообщения
        stats['signals'] += 1
        emoji = '🟢 LONG' if side == 'LONG' else '🔴 SHORT'
        msg = (
            f"⚡️ <b>INSTITUTIONAL SFP #{stats['signals']} | {setup['symbol']}</b>\n"
            f"Направление: <b>{emoji}</b>\n\n"
            f"📍 Вход: <code>{setup['entry']}</code>\n"
            f"🛡 Стоп: <code>{setup['sl']}</code>\n"
            f"🎯 Тейк: <code>{setup['tp']}</code>\n\n"
            f"📊 RR: 1:{setup['rr']} | Bias: {setup['bias']}\n"
            f"📉 Риск: -{setup['risk_pct']}% | 💰 ROI: +{setup['roi']}%\n"
            f"⚙️ Плечо: x{LEVERAGE}"
        )
        # [КОНЕЦ ИЗМЕНЕНИЙ]

        chart_path = await generate_chart(ohlcv_chart, symbol, setup['entry'], setup['sl'], setup['tp'])
        try:
            if chart_path and os.path.exists(chart_path):
                await safe_send_photo(chart_path, msg)
            else:
                await safe_send_message(msg)
            logger.info(f"Сигнал отправлен: {symbol} ({side})")
        finally:
            if chart_path and os.path.exists(chart_path):
                try:
                    os.remove(chart_path)
                except Exception as e:
                    logger.warning(f"Не удалось удалить временный файл графика {chart_path}: {e}")

# ====================== СКАНЕР ======================

async def scanner():
    logger.info('Institutional SFP bot started')
    await exchange.load_markets()  # Один раз при старте

    sem = asyncio.Semaphore(MAX_CONCURRENT_SYMBOLS)

    while True:
        try:
            pairs = await get_top_pairs()
            logger.info(f"Анализ {len(pairs)} пар")

            tasks = []
            for symbol in pairs:
                tasks.append(asyncio.create_task(process_symbol(symbol, sem)))
                await asyncio.sleep(SLEEP_BETWEEN_SYMBOLS)

            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)

            logger.info(f"Цикл завершён. Пауза {ROUND_SLEEP_SECONDS} сек.")
            await asyncio.sleep(ROUND_SLEEP_SECONDS)

        except Exception as e:
            logger.error(f"CRITICAL ERROR: {e}")
            await asyncio.sleep(60)

# ====================== MAIN ======================

async def main():
    try:
        await scanner()
    finally:
        await exchange.close()
        chart_executor.shutdown(wait=True)
        logger.info("Бот остановлен.")

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Остановлено пользователем.")