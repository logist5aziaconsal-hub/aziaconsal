import asyncio
import logging

from config import Config
from exchange.client import BinanceClient
from exchange.pair_selector import PairSelector
from analysis.mtf import MTFAnalyzer
from signals.generator import SignalGenerator
from signals.dedup import SignalDeduplicator
from telegram_bot.bot import TelegramBot
from telegram_bot.sender import SignalSender
from scheduler.orchestrator import ScanOrchestrator
from scheduler.jobs import setup_scheduler
from utils.logging_config import setup_logging


async def main():
    config = Config.from_env()
    setup_logging(config.log_level)
    logger = logging.getLogger("signal_bot")

    logger.info("Initializing SMC Signal Bot...")

    # Initialize components
    client = BinanceClient(config.binance_api_key, config.binance_api_secret)
    tg = TelegramBot(config.telegram_bot_token)

    try:
        pair_selector = PairSelector(client, config.top_pairs_count)
        analyzer = MTFAnalyzer(
            swing_lookback=config.swing_lookback,
            ob_close_mitigation=config.ob_close_mitigation,
        )
        generator = SignalGenerator(min_rr=config.min_rr_ratio)
        dedup = SignalDeduplicator(cooldown_minutes=config.signal_cooldown_minutes)
        sender = SignalSender(tg.bot, config.telegram_channel_id)

        # Initial pair selection
        logger.info("Connecting to Binance and selecting top pairs...")
        pairs = await pair_selector.refresh()
        logger.info(f"Selected {len(pairs)} pairs: {[p.split('/')[0] for p in pairs]}")

        # Setup orchestrator
        orchestrator = ScanOrchestrator(
            client=client,
            pair_selector=pair_selector,
            analyzer=analyzer,
            generator=generator,
            dedup=dedup,
            sender=sender,
        )

        # Setup scheduler
        scheduler = setup_scheduler(
            orchestrator, pair_selector, config.pair_refresh_interval_hours
        )

        # Run initial scan immediately
        logger.info("Running initial scan...")
        await orchestrator.scan_all_pairs()

        # Start scheduler
        scheduler.start()
        logger.info("Scheduler started. Bot is running.")

        # Startup notification
        pair_names = ", ".join(p.split("/")[0] for p in pairs)
        await tg.bot.send_message(
            chat_id=config.telegram_channel_id,
            text=(
                f"<b>SMC Signal Bot started</b>\n"
                f"Monitoring {len(pairs)} pairs: {pair_names}\n"
                f"Timeframes: 1H / 4H / 1D\n"
                f"Min RR: {config.min_rr_ratio}"
            ),
        )

        # Keep running
        while True:
            await asyncio.sleep(3600)

    except (KeyboardInterrupt, SystemExit):
        logger.info("Shutting down...")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
    finally:
        if "scheduler" in dir() and scheduler:
            scheduler.shutdown(wait=False)
        await tg.close()
        await client.close()
        logger.info("Shutdown complete")


if __name__ == "__main__":
    asyncio.run(main())
