import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from scheduler.orchestrator import ScanOrchestrator
from exchange.pair_selector import PairSelector

logger = logging.getLogger(__name__)


def setup_scheduler(
    orchestrator: ScanOrchestrator,
    pair_selector: PairSelector,
    pair_refresh_hours: int = 4,
) -> AsyncIOScheduler:
    """
    Configure APScheduler with cron-based jobs aligned to candle closes.

    Jobs:
        1. Hourly scan at HH:01 (1 min after 1h candle close)
        2. Pair refresh every N hours
    """
    scheduler = AsyncIOScheduler()

    # Main scan — runs 1 minute after each hour
    scheduler.add_job(
        orchestrator.scan_all_pairs,
        CronTrigger(minute=1),
        id="hourly_scan",
        name="Hourly SMC scan",
        max_instances=1,
        misfire_grace_time=120,
    )

    # Pair refresh
    scheduler.add_job(
        pair_selector.refresh,
        CronTrigger(hour=f"*/{pair_refresh_hours}", minute=5),
        id="pair_refresh",
        name="Refresh top pairs by volume",
        max_instances=1,
    )

    logger.info("Scheduler configured: hourly scan at HH:01, pair refresh every %dh", pair_refresh_hours)
    return scheduler
