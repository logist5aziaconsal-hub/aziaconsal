import logging
from exchange.client import BinanceClient
from exchange.pair_selector import PairSelector
from analysis.mtf import MTFAnalyzer
from signals.generator import SignalGenerator
from signals.dedup import SignalDeduplicator
from signals.chart import generate_signal_chart
from telegram_bot.formatter import format_signal
from telegram_bot.sender import SignalSender

logger = logging.getLogger(__name__)


class ScanOrchestrator:
    """
    Coordinates the full scan cycle:
        1. For each active pair
        2. Fetch OHLCV for all timeframes
        3. Run SMC analysis on each timeframe
        4. Generate signals from multi-timeframe confluence
        5. Generate chart with annotations
        6. Deduplicate and send to Telegram
    """

    def __init__(
        self,
        client: BinanceClient,
        pair_selector: PairSelector,
        analyzer: MTFAnalyzer,
        generator: SignalGenerator,
        dedup: SignalDeduplicator,
        sender: SignalSender,
    ):
        self._client = client
        self._pairs = pair_selector
        self._analyzer = analyzer
        self._generator = generator
        self._dedup = dedup
        self._sender = sender

    async def scan_all_pairs(self) -> None:
        """Run a full scan cycle across all active pairs."""
        pairs = self._pairs.pairs
        if not pairs:
            logger.warning("No pairs selected, skipping scan")
            return

        logger.info(f"Starting scan cycle for {len(pairs)} pairs")

        for symbol in pairs:
            try:
                await self._scan_single_pair(symbol)
            except Exception as e:
                logger.error(f"Error scanning {symbol}: {e}", exc_info=True)

        self._dedup.cleanup()
        logger.info("Scan cycle complete")

    async def _scan_single_pair(self, symbol: str) -> None:
        # Fetch OHLCV for each timeframe
        df_1d = await self._client.fetch_ohlcv(symbol, "1d", limit=100)
        df_4h = await self._client.fetch_ohlcv(symbol, "4h", limit=200)
        df_1h = await self._client.fetch_ohlcv(symbol, "1h", limit=500)

        if len(df_1h) < 50 or len(df_4h) < 30 or len(df_1d) < 20:
            logger.warning(f"{symbol}: insufficient data, skipping")
            return

        # Run analysis
        analysis_1d = self._analyzer.analyze("1d", df_1d)
        analysis_4h = self._analyzer.analyze("4h", df_4h)
        analysis_1h = self._analyzer.analyze("1h", df_1h)

        # Generate signals
        signals = self._generator.generate(
            symbol=symbol,
            analysis_1d=analysis_1d,
            analysis_4h=analysis_4h,
            analysis_1h=analysis_1h,
        )

        # Deduplicate, generate chart, and send
        for sig in signals:
            if not self._dedup.is_duplicate(sig.symbol, sig.direction.value):
                msg = format_signal(sig)

                # Generate chart
                chart_png = None
                try:
                    chart_png = generate_signal_chart(sig, df_1h)
                    if chart_png:
                        logger.info(f"{symbol}: chart generated ({len(chart_png)} bytes)")
                except Exception as e:
                    logger.warning(f"{symbol}: chart generation failed: {e}")

                sent = await self._sender.send(msg, chart_png=chart_png)
                if sent:
                    self._dedup.record(sig.symbol, sig.direction.value)
