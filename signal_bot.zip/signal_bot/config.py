import os
from dataclasses import dataclass, field
from dotenv import load_dotenv


@dataclass(frozen=True)
class Config:
    # Binance
    binance_api_key: str
    binance_api_secret: str

    # Telegram
    telegram_bot_token: str
    telegram_channel_id: str

    # Trading
    top_pairs_count: int = 10
    timeframes: list[str] = field(default_factory=lambda: ["1h", "4h", "1d"])
    swing_lookback: int = 10
    ob_close_mitigation: bool = False
    min_rr_ratio: float = 2.0
    signal_cooldown_minutes: int = 60

    # System
    log_level: str = "INFO"
    pair_refresh_interval_hours: int = 4

    @classmethod
    def from_env(cls) -> "Config":
        load_dotenv()
        return cls(
            binance_api_key=os.getenv("BINANCE_API_KEY", ""),
            binance_api_secret=os.getenv("BINANCE_API_SECRET", ""),
            telegram_bot_token=os.environ["TELEGRAM_BOT_TOKEN"],
            telegram_channel_id=os.environ["TELEGRAM_CHANNEL_ID"],
            top_pairs_count=int(os.getenv("TOP_PAIRS_COUNT", "10")),
            timeframes=os.getenv("TIMEFRAMES", "1h,4h,1d").split(","),
            swing_lookback=int(os.getenv("SWING_LOOKBACK", "10")),
            ob_close_mitigation=os.getenv("OB_CLOSE_MITIGATION", "false").lower() == "true",
            min_rr_ratio=float(os.getenv("MIN_RR_RATIO", "2.0")),
            signal_cooldown_minutes=int(os.getenv("SIGNAL_COOLDOWN_MINUTES", "60")),
            log_level=os.getenv("LOG_LEVEL", "INFO"),
            pair_refresh_interval_hours=int(os.getenv("PAIR_REFRESH_INTERVAL_HOURS", "4")),
        )
