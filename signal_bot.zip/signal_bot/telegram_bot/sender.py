import asyncio
import logging
from aiogram import Bot
from aiogram.types import BufferedInputFile

logger = logging.getLogger(__name__)


class SignalSender:
    """Sends formatted signal messages with chart to the Telegram channel."""

    def __init__(self, bot: Bot, channel_id: str, max_retries: int = 3):
        self._bot = bot
        self._channel_id = channel_id
        self._max_retries = max_retries

    async def send(self, text: str, chart_png: bytes | None = None) -> bool:
        """
        Send signal to Telegram channel.
        If chart_png is provided, sends as photo with caption.
        Otherwise sends as plain text message.
        """
        for attempt in range(1, self._max_retries + 1):
            try:
                if chart_png:
                    photo = BufferedInputFile(chart_png, filename="signal_chart.png")
                    await self._bot.send_photo(
                        chat_id=self._channel_id,
                        photo=photo,
                        caption=text,
                        parse_mode="HTML",
                    )
                else:
                    await self._bot.send_message(
                        chat_id=self._channel_id,
                        text=text,
                        disable_web_page_preview=True,
                    )
                logger.info("Signal sent to channel")
                return True
            except Exception as e:
                logger.warning(f"Send attempt {attempt}/{self._max_retries} failed: {e}")
                if attempt < self._max_retries:
                    await asyncio.sleep(2**attempt)

        logger.error("Failed to send signal after all retries")
        return False
