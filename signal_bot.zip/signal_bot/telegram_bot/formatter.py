from signals.models import Signal, SignalDirection


def format_signal(signal: Signal) -> str:
    """Format a Signal into a Telegram HTML message with ROI at leverage."""
    emoji = "\U0001f7e2" if signal.direction == SignalDirection.LONG else "\U0001f534"
    dir_label = signal.direction.value
    sym = signal.display_symbol
    lev = signal.leverage

    sl_pct = abs(signal.entry_price - signal.stop_loss) / signal.entry_price * 100

    lines = [
        f"<b>{emoji} {dir_label} {sym}  x{lev}</b>  [{signal.confidence}]",
        "\u2500" * 24,
        f"<b>Entry:</b>  <code>{_fmt(signal.entry_price)}</code>",
        "",
        f"<b>SL:</b>     <code>{_fmt(signal.stop_loss)}</code>  "
        f"(-{sl_pct:.2f}%)  "
        f"\u2192 <b>ROI: {signal.roi_sl}%</b>",
        "",
        f"<b>TP1:</b>    <code>{_fmt(signal.take_profit_1)}</code>  (1:2)  "
        f"\u2192 <b>ROI: +{signal.roi_tp1}%</b> \U0001f4b0",
        "",
        f"<b>TP2:</b>    <code>{_fmt(signal.take_profit_2)}</code>  (1:3)  "
        f"\u2192 <b>ROI: +{signal.roi_tp2}%</b> \U0001f525",
    ]

    if signal.take_profit_liq is not None and signal.roi_tp_liq is not None:
        lines.extend([
            "",
            f"<b>TP Liq:</b> <code>{_fmt(signal.take_profit_liq)}</code>  "
            f"\u2192 <b>ROI: +{signal.roi_tp_liq}%</b> \U0001f3af",
        ])

    # Liquidation price warning
    liq_price = signal.liquidation_price
    if liq_price is not None:
        lines.extend([
            "",
            f"\u26a0\ufe0f <b>Liq price:</b> <code>{_fmt(liq_price)}</code>",
        ])

    lines.extend([
        "",
        "\u2500" * 24,
        f"<b>OB Zone:</b> {_fmt(signal.order_block_bottom)} \u2014 {_fmt(signal.order_block_top)} ({signal.timeframe_structure})",
        f"<b>Trend:</b> {signal.trend_direction} ({signal.timeframe_trend})",
        f"<b>Entry TF:</b> {signal.timeframe_entry} | <b>Structure:</b> {signal.timeframe_structure}",
        f"<b>RR:</b> {signal.rr_ratio}",
        "",
        f"<i>{signal.created_at.strftime('%Y-%m-%d %H:%M UTC')}</i>",
    ])

    return "\n".join(lines)


def _fmt(price: float) -> str:
    """Smart price formatting: more decimals for small prices."""
    if price >= 1000:
        return f"{price:,.2f}"
    elif price >= 1:
        return f"{price:,.4f}"
    else:
        return f"{price:.6f}"
