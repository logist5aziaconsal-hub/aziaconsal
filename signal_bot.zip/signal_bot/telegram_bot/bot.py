import aiohttp
from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode


class TelegramBot:
    def __init__(self, token: str):
        session = AiohttpSession()
        # Override connector resolver to use ThreadedResolver
        # instead of aiodns (which has DNS timeout issues)
        session._connector_init["resolver"] = aiohttp.resolver.ThreadedResolver()

        self._bot = Bot(
            token=token,
            session=session,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        )

    @property
    def bot(self) -> Bot:
        return self._bot

    async def close(self) -> None:
        await self._bot.session.close()
