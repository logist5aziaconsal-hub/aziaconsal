import numpy as np
import pandas as pd


def detect_swing_points(df: pd.DataFrame, lookback: int = 10) -> pd.DataFrame:
    """
    Identify swing highs and swing lows.

    A swing high at index i: high[i] == max(high[i-lookback : i+lookback+1])
    A swing low at index i:  low[i]  == min(low[i-lookback : i+lookback+1])

    Returns DataFrame with columns:
        - swing_type: 1 (swing high), -1 (swing low), 0 (neither)
        - swing_level: price level of the swing point (NaN if not a swing)
    """
    highs = df["high"].values
    lows = df["low"].values
    n = len(df)

    swing_type = np.zeros(n, dtype=np.int8)
    swing_level = np.full(n, np.nan)

    for i in range(lookback, n - lookback):
        window_high = highs[i - lookback : i + lookback + 1]
        window_low = lows[i - lookback : i + lookback + 1]

        is_swing_high = highs[i] == window_high.max()
        is_swing_low = lows[i] == window_low.min()

        if is_swing_high and is_swing_low:
            # Both — pick based on relative body size
            body = abs(df["close"].iloc[i] - df["open"].iloc[i])
            upper_wick = highs[i] - max(df["close"].iloc[i], df["open"].iloc[i])
            lower_wick = min(df["close"].iloc[i], df["open"].iloc[i]) - lows[i]
            if upper_wick >= lower_wick:
                swing_type[i] = 1
                swing_level[i] = highs[i]
            else:
                swing_type[i] = -1
                swing_level[i] = lows[i]
        elif is_swing_high:
            swing_type[i] = 1
            swing_level[i] = highs[i]
        elif is_swing_low:
            swing_type[i] = -1
            swing_level[i] = lows[i]

    # Enforce alternation: high-low-high-low
    # When consecutive same-type swings, keep the more extreme one
    _enforce_alternation(swing_type, swing_level)

    return pd.DataFrame(
        {"swing_type": swing_type, "swing_level": swing_level},
        index=df.index,
    )


def _enforce_alternation(
    swing_type: np.ndarray, swing_level: np.ndarray
) -> None:
    """Remove consecutive same-type swings, keeping the most extreme."""
    n = len(swing_type)
    last_type = 0
    last_idx = -1

    for i in range(n):
        if swing_type[i] == 0:
            continue

        if swing_type[i] == last_type:
            # Same type consecutive: keep the higher high or lower low
            if swing_type[i] == 1:
                if swing_level[i] >= swing_level[last_idx]:
                    swing_type[last_idx] = 0
                    swing_level[last_idx] = np.nan
                    last_idx = i
                else:
                    swing_type[i] = 0
                    swing_level[i] = np.nan
            else:  # -1
                if swing_level[i] <= swing_level[last_idx]:
                    swing_type[last_idx] = 0
                    swing_level[last_idx] = np.nan
                    last_idx = i
                else:
                    swing_type[i] = 0
                    swing_level[i] = np.nan
        else:
            last_type = swing_type[i]
            last_idx = i
