import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Optional


@dataclass
class OrderBlock:
    index: pd.Timestamp  # when the OB candle occurred
    direction: int  # 1 = bullish OB (demand), -1 = bearish OB (supply)
    top: float  # high of the OB candle
    bottom: float  # low of the OB candle
    mitigated: bool = False
    mitigation_index: Optional[pd.Timestamp] = None


def detect_order_blocks(
    df: pd.DataFrame,
    swings: pd.DataFrame,
    bos_df: pd.DataFrame,
    close_mitigation: bool = False,
) -> list[OrderBlock]:
    """
    Detect Order Blocks based on SMC/ICT methodology.

    Bullish OB: last bearish candle before a bullish BOS impulse.
    Bearish OB: last bullish candle before a bearish BOS impulse.

    An OB is mitigated when price fully passes through its zone.
    """
    obs: list[OrderBlock] = []
    opens = df["open"].values
    closes = df["close"].values
    highs = df["high"].values
    lows = df["low"].values
    bos_vals = bos_df["bos"].values
    n = len(df)

    for i in range(1, n):
        if bos_vals[i] == 0:
            continue

        if bos_vals[i] == 1:
            # Bullish BOS — find last bearish candle before impulse
            for j in range(i - 1, max(i - 20, -1), -1):
                if closes[j] < opens[j]:  # bearish candle
                    obs.append(
                        OrderBlock(
                            index=df.index[j],
                            direction=1,
                            top=highs[j],
                            bottom=lows[j],
                        )
                    )
                    break

        elif bos_vals[i] == -1:
            # Bearish BOS — find last bullish candle before impulse
            for j in range(i - 1, max(i - 20, -1), -1):
                if closes[j] > opens[j]:  # bullish candle
                    obs.append(
                        OrderBlock(
                            index=df.index[j],
                            direction=-1,
                            top=highs[j],
                            bottom=lows[j],
                        )
                    )
                    break

    # Check mitigation for all OBs
    for ob in obs:
        ob_candle_pos = df.index.get_loc(ob.index)
        for k in range(ob_candle_pos + 1, n):
            if ob.direction == 1:
                # Bullish OB mitigated if price drops through bottom
                check = closes[k] if close_mitigation else lows[k]
                if check < ob.bottom:
                    ob.mitigated = True
                    ob.mitigation_index = df.index[k]
                    break
            else:
                # Bearish OB mitigated if price rises through top
                check = closes[k] if close_mitigation else highs[k]
                if check > ob.top:
                    ob.mitigated = True
                    ob.mitigation_index = df.index[k]
                    break

    return obs


def get_active_order_blocks(obs: list[OrderBlock]) -> list[OrderBlock]:
    """Return only unmitigated (still valid) order blocks."""
    return [ob for ob in obs if not ob.mitigated]
