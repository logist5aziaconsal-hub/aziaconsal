import numpy as np
import pandas as pd
from dataclasses import dataclass


@dataclass
class LiquidityGrab:
    index: pd.Timestamp  # candle where the grab occurred
    direction: int  # 1 = grab below (bullish signal), -1 = grab above (bearish signal)
    swept_level: float  # the swing level that was swept
    wick_extreme: float  # how far the wick went beyond the level
    close_price: float  # where the candle closed


def detect_liquidity_grabs(
    df: pd.DataFrame,
    swings: pd.DataFrame,
) -> list[LiquidityGrab]:
    """
    Detect liquidity grabs (stop hunts).

    Grab BELOW swing low (bullish): wick goes below swing low, close above it.
    Grab ABOVE swing high (bearish): wick goes above swing high, close below it.
    """
    grabs: list[LiquidityGrab] = []
    highs = df["high"].values
    lows = df["low"].values
    closes = df["close"].values
    swing_types = swings["swing_type"].values
    swing_levels = swings["swing_level"].values
    n = len(df)

    # Collect swing levels with their indices
    swing_high_levels: list[tuple[int, float]] = []
    swing_low_levels: list[tuple[int, float]] = []

    for i in range(n):
        if swing_types[i] == 1:
            swing_high_levels.append((i, swing_levels[i]))
        elif swing_types[i] == -1:
            swing_low_levels.append((i, swing_levels[i]))

    # For each candle, check if it grabs liquidity from prior swing levels
    for i in range(1, n):
        grabbed_below = False
        grabbed_above = False

        # Check grab below swing lows (bullish signal)
        for si, level in swing_low_levels:
            if si >= i:
                break
            if lows[i] < level and closes[i] > level:
                grabs.append(
                    LiquidityGrab(
                        index=df.index[i],
                        direction=1,
                        swept_level=level,
                        wick_extreme=lows[i],
                        close_price=closes[i],
                    )
                )
                grabbed_below = True
                break  # one grab per candle per direction

        # Check grab above swing highs (bearish signal)
        for si, level in swing_high_levels:
            if si >= i:
                break
            if highs[i] > level and closes[i] < level:
                grabs.append(
                    LiquidityGrab(
                        index=df.index[i],
                        direction=-1,
                        swept_level=level,
                        wick_extreme=highs[i],
                        close_price=closes[i],
                    )
                )
                grabbed_above = True
                break

    return grabs
