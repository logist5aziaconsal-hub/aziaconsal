import numpy as np
import pandas as pd
from enum import IntEnum


class Trend(IntEnum):
    BEARISH = -1
    NEUTRAL = 0
    BULLISH = 1


def detect_bos(df: pd.DataFrame, swings: pd.DataFrame) -> pd.DataFrame:
    """
    Detect Break of Structure (BOS).

    Bullish BOS: close breaks above the most recent swing high.
    Bearish BOS: close breaks below the most recent swing low.

    Returns DataFrame with columns:
        - bos: 1 (bullish BOS), -1 (bearish BOS), 0 (none)
        - bos_level: the swing level that was broken
    """
    n = len(df)
    closes = df["close"].values
    swing_types = swings["swing_type"].values
    swing_levels = swings["swing_level"].values

    bos = np.zeros(n, dtype=np.int8)
    bos_level = np.full(n, np.nan)

    last_swing_high = np.nan
    last_swing_low = np.nan

    for i in range(n):
        # Update latest swing references
        if swing_types[i] == 1:
            last_swing_high = swing_levels[i]
        elif swing_types[i] == -1:
            last_swing_low = swing_levels[i]

        # Check for BOS (only on candles AFTER the swing was established)
        if not np.isnan(last_swing_high) and closes[i] > last_swing_high:
            bos[i] = 1
            bos_level[i] = last_swing_high
            last_swing_high = np.nan  # consumed — wait for next swing high

        if not np.isnan(last_swing_low) and closes[i] < last_swing_low:
            bos[i] = -1
            bos_level[i] = last_swing_low
            last_swing_low = np.nan

    return pd.DataFrame({"bos": bos, "bos_level": bos_level}, index=df.index)


def determine_trend(bos_df: pd.DataFrame) -> pd.Series:
    """
    Determine current trend from BOS events.
    Last BOS direction = current trend.
    """
    n = len(bos_df)
    trend = np.full(n, Trend.NEUTRAL, dtype=int)
    last_bos = Trend.NEUTRAL

    for i in range(n):
        if bos_df["bos"].iloc[i] == 1:
            last_bos = Trend.BULLISH
        elif bos_df["bos"].iloc[i] == -1:
            last_bos = Trend.BEARISH
        trend[i] = last_bos

    return pd.Series(trend, index=bos_df.index, name="trend")
