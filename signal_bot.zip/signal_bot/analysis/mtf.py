import pandas as pd
from dataclasses import dataclass

from analysis.swing import detect_swing_points
from analysis.structure import detect_bos, determine_trend, Trend
from analysis.order_blocks import (
    detect_order_blocks,
    get_active_order_blocks,
    OrderBlock,
)
from analysis.liquidity import detect_liquidity_grabs, LiquidityGrab


@dataclass
class TimeframeAnalysis:
    timeframe: str
    df: pd.DataFrame
    swings: pd.DataFrame
    bos: pd.DataFrame
    trend: pd.Series
    order_blocks: list[OrderBlock]
    active_obs: list[OrderBlock]
    liquidity_grabs: list[LiquidityGrab]


class MTFAnalyzer:
    """
    Runs SMC analysis across multiple timeframes for a single symbol.

    - 1D: higher-timeframe trend direction (filter)
    - 4H: structure (BOS) and order blocks (setup zone)
    - 1H: liquidity grabs and precise entry timing
    """

    def __init__(self, swing_lookback: int = 10, ob_close_mitigation: bool = False):
        self._swing_lookback = swing_lookback
        self._ob_close_mitigation = ob_close_mitigation

    def analyze(self, tf: str, df: pd.DataFrame) -> TimeframeAnalysis:
        """Run full SMC analysis pipeline on a single timeframe."""
        swings = detect_swing_points(df, lookback=self._swing_lookback)
        bos = detect_bos(df, swings)
        trend = determine_trend(bos)
        obs = detect_order_blocks(
            df, swings, bos, close_mitigation=self._ob_close_mitigation
        )
        active_obs = get_active_order_blocks(obs)
        grabs = detect_liquidity_grabs(df, swings)

        return TimeframeAnalysis(
            timeframe=tf,
            df=df,
            swings=swings,
            bos=bos,
            trend=trend,
            order_blocks=obs,
            active_obs=active_obs,
            liquidity_grabs=grabs,
        )
