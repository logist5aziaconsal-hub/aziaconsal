import logging
from exchange.client import BinanceClient

logger = logging.getLogger(__name__)


class PairSelector:
    """Selects top-N Binance Futures USDT pairs by 24h quote volume."""

    def __init__(self, client: BinanceClient, top_n: int = 10):
        self._client = client
        self._top_n = top_n
        self._cached_pairs: list[str] = []

    async def refresh(self) -> list[str]:
        tickers = await self._client.fetch_all_tickers()

        usdt_futures = []
        for symbol, ticker in tickers.items():
            if "/USDT:USDT" in symbol:
                qv = ticker.get("quoteVolume") or 0
                usdt_futures.append((symbol, float(qv)))

        usdt_futures.sort(key=lambda x: x[1], reverse=True)
        self._cached_pairs = [sym for sym, _ in usdt_futures[: self._top_n]]

        logger.info(
            f"Selected top-{self._top_n} pairs: "
            f"{[p.split('/')[0] for p in self._cached_pairs]}"
        )
        return self._cached_pairs

    @property
    def pairs(self) -> list[str]:
        return self._cached_pairs
