import asyncio
import aiohttp
import ccxt.async_support as ccxt
import pandas as pd
import logging

logger = logging.getLogger(__name__)

MAX_RETRIES = 3


class BinanceClient:
    """Async wrapper around ccxt for Binance Futures (USDT-margined)."""

    def __init__(self, api_key: str = "", api_secret: str = ""):
        # Use ThreadedResolver instead of aiodns to avoid DNS issues
        connector = aiohttp.TCPConnector(
            resolver=aiohttp.resolver.ThreadedResolver(),
        )
        session = aiohttp.ClientSession(connector=connector)

        opts = {
            "enableRateLimit": True,
            "timeout": 30000,  # 30 seconds
            "session": session,
            "options": {"defaultType": "future"},
        }
        if api_key:
            opts["apiKey"] = api_key
        if api_secret:
            opts["secret"] = api_secret

        self._exchange = ccxt.binance(opts)
        self._markets_loaded = False

    async def ensure_markets(self) -> None:
        if not self._markets_loaded:
            for attempt in range(1, MAX_RETRIES + 1):
                try:
                    await self._exchange.load_markets()
                    self._markets_loaded = True
                    logger.info("Binance markets loaded")
                    return
                except (ccxt.RequestTimeout, ccxt.NetworkError) as e:
                    logger.warning(
                        f"load_markets attempt {attempt}/{MAX_RETRIES} failed: {e}"
                    )
                    if attempt < MAX_RETRIES:
                        await asyncio.sleep(3 * attempt)
                    else:
                        raise

    async def fetch_ohlcv(
        self, symbol: str, timeframe: str, limit: int = 500
    ) -> pd.DataFrame:
        """Fetch OHLCV and return a pandas DataFrame."""
        await self.ensure_markets()
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                raw = await self._exchange.fetch_ohlcv(
                    symbol, timeframe, limit=limit
                )
                break
            except (ccxt.RequestTimeout, ccxt.NetworkError) as e:
                logger.warning(
                    f"fetch_ohlcv {symbol} {timeframe} attempt {attempt}/{MAX_RETRIES}: {e}"
                )
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(2 * attempt)
                else:
                    raise

        df = pd.DataFrame(
            raw, columns=["timestamp", "open", "high", "low", "close", "volume"]
        )
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        df.set_index("timestamp", inplace=True)
        df = df.astype(float)
        return df

    async def fetch_all_tickers(self) -> dict:
        """Fetch all futures tickers (single API call)."""
        await self.ensure_markets()
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                return await self._exchange.fetch_tickers()
            except (ccxt.RequestTimeout, ccxt.NetworkError) as e:
                logger.warning(
                    f"fetch_tickers attempt {attempt}/{MAX_RETRIES}: {e}"
                )
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(2 * attempt)
                else:
                    raise

    async def close(self) -> None:
        await self._exchange.close()
