import numpy as np
import pandas as pd
from signals.models import SignalDirection
from analysis.order_blocks import OrderBlock


def calculate_sl_tp(
    direction: SignalDirection,
    entry: float,
    ob: OrderBlock,
    swings_1h: pd.DataFrame,
    df_1h: pd.DataFrame,
) -> tuple[float, float, float, float | None]:
    """
    Calculate Stop Loss and Take Profit levels.

    SL: beyond OB zone + 0.1% buffer.
    TP1: 1:2 RR, TP2: 1:3 RR.
    TP_liq: next opposite swing level (liquidity target).

    Returns: (sl, tp1, tp2, tp_liq)
    """
    buffer_pct = 0.001  # 0.1% buffer

    swing_types = swings_1h["swing_type"].values
    swing_levels = swings_1h["swing_level"].values

    if direction == SignalDirection.LONG:
        sl = ob.bottom * (1 - buffer_pct)
        risk = entry - sl
        tp1 = entry + (risk * 2)
        tp2 = entry + (risk * 3)

        # Find next swing high above entry as liquidity target
        tp_liq = None
        for i in range(len(swing_types) - 1, -1, -1):
            if swing_types[i] == 1 and not np.isnan(swing_levels[i]):
                if swing_levels[i] > entry:
                    tp_liq = float(swing_levels[i])
                    break

    else:  # SHORT
        sl = ob.top * (1 + buffer_pct)
        risk = sl - entry
        tp1 = entry - (risk * 2)
        tp2 = entry - (risk * 3)

        tp_liq = None
        for i in range(len(swing_types) - 1, -1, -1):
            if swing_types[i] == -1 and not np.isnan(swing_levels[i]):
                if swing_levels[i] < entry:
                    tp_liq = float(swing_levels[i])
                    break

    return sl, tp1, tp2, tp_liq
