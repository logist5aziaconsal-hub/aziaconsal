import logging
from datetime import datetime, timezone

from analysis.mtf import TimeframeAnalysis
from analysis.structure import Trend
from signals.models import Signal, SignalDirection
from signals.risk import calculate_sl_tp

logger = logging.getLogger(__name__)


class SignalGenerator:
    """
    Combines multi-timeframe SMC analysis into actionable trading signals.

    LONG conditions (all must be true):
        1. Daily trend = BULLISH
        2. 4H has active bullish Order Block
        3. 1H has recent liquidity grab below swing low (last 3 candles)
        4. Current price is within/touching the 4H bullish OB zone
        5. RR >= min_rr

    SHORT conditions: mirror of LONG.

    Confidence = HIGH if 1H also has confirming BOS, else MEDIUM.
    """

    def __init__(self, min_rr: float = 2.0):
        self._min_rr = min_rr

    def generate(
        self,
        symbol: str,
        analysis_1d: TimeframeAnalysis,
        analysis_4h: TimeframeAnalysis,
        analysis_1h: TimeframeAnalysis,
    ) -> list[Signal]:
        signals: list[Signal] = []

        daily_trend = analysis_1d.trend.iloc[-1]
        current_price = float(analysis_1h.df["close"].iloc[-1])

        # --- LONG SIGNALS ---
        if daily_trend == Trend.BULLISH:
            long_signals = self._check_long(
                symbol, current_price, analysis_4h, analysis_1h
            )
            signals.extend(long_signals)

        # --- SHORT SIGNALS ---
        if daily_trend == Trend.BEARISH:
            short_signals = self._check_short(
                symbol, current_price, analysis_4h, analysis_1h
            )
            signals.extend(short_signals)

        if signals:
            logger.info(f"{symbol}: generated {len(signals)} signal(s)")

        return signals

    def _check_long(
        self,
        symbol: str,
        current_price: float,
        analysis_4h: TimeframeAnalysis,
        analysis_1h: TimeframeAnalysis,
    ) -> list[Signal]:
        signals = []

        bullish_obs_4h = [
            ob for ob in analysis_4h.active_obs if ob.direction == 1
        ]
        if not bullish_obs_4h:
            return signals

        # Recent liquidity grabs below swing lows on 1H (last 3 candles)
        recent_cutoff = analysis_1h.df.index[-3] if len(analysis_1h.df) >= 3 else analysis_1h.df.index[0]
        recent_grabs = [
            g
            for g in analysis_1h.liquidity_grabs
            if g.direction == 1 and g.index >= recent_cutoff
        ]
        if not recent_grabs:
            return signals

        for ob in bullish_obs_4h:
            # Price should be in or near the OB zone (small tolerance above)
            if not (ob.bottom <= current_price <= ob.top * 1.002):
                continue

            sl, tp1, tp2, tp_liq = calculate_sl_tp(
                direction=SignalDirection.LONG,
                entry=current_price,
                ob=ob,
                swings_1h=analysis_1h.swings,
                df_1h=analysis_1h.df,
            )

            if current_price <= sl:
                continue

            rr = (tp1 - current_price) / (current_price - sl)
            if rr < self._min_rr:
                continue

            # Confidence: HIGH if 1H has confirming bullish BOS recently
            has_1h_bos = bool((analysis_1h.bos["bos"].iloc[-3:] == 1).any())
            confidence = "HIGH" if has_1h_bos else "MEDIUM"

            signals.append(
                Signal(
                    symbol=symbol,
                    direction=SignalDirection.LONG,
                    entry_price=current_price,
                    stop_loss=round(sl, 8),
                    take_profit_1=round(tp1, 8),
                    take_profit_2=round(tp2, 8),
                    take_profit_liq=round(tp_liq, 8) if tp_liq else None,
                    rr_ratio=round(rr, 2),
                    order_block_top=ob.top,
                    order_block_bottom=ob.bottom,
                    timeframe_entry="1h",
                    timeframe_structure="4h",
                    timeframe_trend="1d",
                    trend_direction="BULLISH",
                    created_at=datetime.now(timezone.utc),
                    confidence=confidence,
                )
            )
            break  # one signal per scan for this direction

        return signals

    def _check_short(
        self,
        symbol: str,
        current_price: float,
        analysis_4h: TimeframeAnalysis,
        analysis_1h: TimeframeAnalysis,
    ) -> list[Signal]:
        signals = []

        bearish_obs_4h = [
            ob for ob in analysis_4h.active_obs if ob.direction == -1
        ]
        if not bearish_obs_4h:
            return signals

        recent_cutoff = analysis_1h.df.index[-3] if len(analysis_1h.df) >= 3 else analysis_1h.df.index[0]
        recent_grabs = [
            g
            for g in analysis_1h.liquidity_grabs
            if g.direction == -1 and g.index >= recent_cutoff
        ]
        if not recent_grabs:
            return signals

        for ob in bearish_obs_4h:
            if not (ob.bottom * 0.998 <= current_price <= ob.top):
                continue

            sl, tp1, tp2, tp_liq = calculate_sl_tp(
                direction=SignalDirection.SHORT,
                entry=current_price,
                ob=ob,
                swings_1h=analysis_1h.swings,
                df_1h=analysis_1h.df,
            )

            if sl <= current_price:
                continue

            rr = (current_price - tp1) / (sl - current_price)
            if rr < self._min_rr:
                continue

            has_1h_bos = bool((analysis_1h.bos["bos"].iloc[-3:] == -1).any())
            confidence = "HIGH" if has_1h_bos else "MEDIUM"

            signals.append(
                Signal(
                    symbol=symbol,
                    direction=SignalDirection.SHORT,
                    entry_price=current_price,
                    stop_loss=round(sl, 8),
                    take_profit_1=round(tp1, 8),
                    take_profit_2=round(tp2, 8),
                    take_profit_liq=round(tp_liq, 8) if tp_liq else None,
                    rr_ratio=round(rr, 2),
                    order_block_top=ob.top,
                    order_block_bottom=ob.bottom,
                    timeframe_entry="1h",
                    timeframe_structure="4h",
                    timeframe_trend="1d",
                    trend_direction="BEARISH",
                    created_at=datetime.now(timezone.utc),
                    confidence=confidence,
                )
            )
            break

        return signals
