from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class SignalDirection(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"


@dataclass
class Signal:
    symbol: str
    direction: SignalDirection
    entry_price: float
    stop_loss: float
    take_profit_1: float  # 1:2 RR
    take_profit_2: float  # 1:3 RR
    take_profit_liq: float | None  # next liquidity pool target
    rr_ratio: float
    order_block_top: float
    order_block_bottom: float
    timeframe_entry: str  # "1h"
    timeframe_structure: str  # "4h"
    timeframe_trend: str  # "1d"
    trend_direction: str  # "BULLISH" / "BEARISH"
    created_at: datetime
    confidence: str  # "HIGH" / "MEDIUM"
    leverage: int = 40  # default leverage for ROI calculation

    @property
    def risk_pips(self) -> float:
        return abs(self.entry_price - self.stop_loss)

    @property
    def display_symbol(self) -> str:
        """BTC/USDT:USDT -> BTCUSDT"""
        return self.symbol.replace("/", "").replace(":USDT", "")

    # --- ROI calculations at given leverage ---

    @property
    def roi_tp1(self) -> float:
        """ROI % at TP1 with leverage."""
        pct = abs(self.take_profit_1 - self.entry_price) / self.entry_price
        return round(pct * self.leverage * 100, 2)

    @property
    def roi_tp2(self) -> float:
        """ROI % at TP2 with leverage."""
        pct = abs(self.take_profit_2 - self.entry_price) / self.entry_price
        return round(pct * self.leverage * 100, 2)

    @property
    def roi_tp_liq(self) -> float | None:
        """ROI % at TP Liq with leverage."""
        if self.take_profit_liq is None:
            return None
        pct = abs(self.take_profit_liq - self.entry_price) / self.entry_price
        return round(pct * self.leverage * 100, 2)

    @property
    def roi_sl(self) -> float:
        """ROI % loss at SL with leverage (negative value)."""
        pct = abs(self.stop_loss - self.entry_price) / self.entry_price
        return round(-pct * self.leverage * 100, 2)

    @property
    def liquidation_price(self) -> float | None:
        """Estimated liquidation price at leverage (simplified, ~100/lev %)."""
        liq_pct = 1.0 / self.leverage  # e.g. 2.5% for x40
        if self.direction == SignalDirection.LONG:
            return round(self.entry_price * (1 - liq_pct), 8)
        else:
            return round(self.entry_price * (1 + liq_pct), 8)
