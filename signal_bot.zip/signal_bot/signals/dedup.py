from datetime import datetime, timedelta, timezone


class SignalDeduplicator:
    """Prevents duplicate signals for the same symbol+direction within a cooldown."""

    def __init__(self, cooldown_minutes: int = 60):
        self._cooldown = timedelta(minutes=cooldown_minutes)
        self._history: dict[str, datetime] = {}

    def _key(self, symbol: str, direction: str) -> str:
        return f"{symbol}:{direction}"

    def is_duplicate(self, symbol: str, direction: str) -> bool:
        key = self._key(symbol, direction)
        last = self._history.get(key)
        if last and (datetime.now(timezone.utc) - last) < self._cooldown:
            return True
        return False

    def record(self, symbol: str, direction: str) -> None:
        key = self._key(symbol, direction)
        self._history[key] = datetime.now(timezone.utc)

    def cleanup(self) -> None:
        """Remove expired entries."""
        now = datetime.now(timezone.utc)
        expired = [
            k for k, v in self._history.items() if (now - v) > self._cooldown * 2
        ]
        for k in expired:
            del self._history[k]
