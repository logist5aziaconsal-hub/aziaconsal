import io
import logging
import matplotlib
matplotlib.use("Agg")  # non-interactive backend

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.dates as mdates
import mplfinance as mpf
import pandas as pd
import numpy as np
from datetime import timedelta

from signals.models import Signal, SignalDirection

logger = logging.getLogger(__name__)

# ── Dark theme style ──────────────────────────────────────────────
DARK_BG = "#0e1117"
PANEL_BG = "#161b22"
GRID_COLOR = "#21262d"
TEXT_COLOR = "#e6edf3"
GREEN = "#00c853"
RED = "#ff1744"
OB_BULL_COLOR = "#00c85330"  # semi-transparent green
OB_BEAR_COLOR = "#ff174430"  # semi-transparent red
ENTRY_COLOR = "#ffffff"
SL_COLOR = "#ff1744"
TP_COLOR = "#00c853"
TP2_COLOR = "#00e676"
LIQ_COLOR = "#ffd600"


def generate_signal_chart(signal: Signal, df_1h: pd.DataFrame) -> bytes:
    """
    Generate a candlestick chart with SMC annotations as PNG bytes.

    Shows:
        - Last 60 candles (1H)
        - Order Block zone (shaded rectangle)
        - Entry line (white dashed)
        - Stop Loss line (red dashed)
        - TP1, TP2 lines (green dashed)
        - TP Liq line (yellow dashed, if available)
        - Liquidation price line (red dotted)
        - ROI labels on right side
    """
    # Use last 60 candles for clear view
    n_candles = 60
    df = df_1h.tail(n_candles).copy()

    if len(df) < 10:
        logger.warning("Not enough candles for chart")
        return b""

    # ── Build mplfinance style ──
    mc = mpf.make_marketcolors(
        up=GREEN,
        down=RED,
        edge={"up": GREEN, "down": RED},
        wick={"up": GREEN, "down": RED},
        volume="in",
    )
    style = mpf.make_mpf_style(
        base_mpf_style="nightclouds",
        marketcolors=mc,
        facecolor=DARK_BG,
        figcolor=DARK_BG,
        gridcolor=GRID_COLOR,
        gridstyle="--",
        gridaxis="both",
        y_on_right=True,
        rc={
            "axes.labelcolor": TEXT_COLOR,
            "xtick.color": TEXT_COLOR,
            "ytick.color": TEXT_COLOR,
            "font.size": 9,
        },
    )

    # ── Plot ──
    fig, axes = mpf.plot(
        df,
        type="candle",
        style=style,
        volume=True,
        figsize=(14, 8),
        returnfig=True,
        tight_layout=True,
    )

    ax = axes[0]  # price axis
    ax_vol = axes[2]  # volume axis

    # x-axis limits
    x_min = -1
    x_max = len(df) + 1

    # ── Draw Order Block zone ──
    ob_color = OB_BULL_COLOR if signal.direction == SignalDirection.LONG else OB_BEAR_COLOR
    ob_edge = GREEN if signal.direction == SignalDirection.LONG else RED
    ax.axhspan(
        signal.order_block_bottom,
        signal.order_block_top,
        alpha=0.2,
        facecolor=ob_edge,
        edgecolor=ob_edge,
        linewidth=1,
        linestyle="-",
        label="Order Block",
    )

    # ── Draw horizontal lines ──
    line_cfg = {
        "linewidth": 1.2,
        "linestyle": "--",
    }

    # Entry
    ax.axhline(
        signal.entry_price,
        color=ENTRY_COLOR,
        **line_cfg,
        label=f"Entry {_fmt(signal.entry_price)}",
    )
    ax.text(
        x_max + 0.3,
        signal.entry_price,
        f"  ENTRY\n  {_fmt(signal.entry_price)}",
        color=ENTRY_COLOR,
        fontsize=8,
        fontweight="bold",
        va="center",
        ha="left",
        bbox=dict(boxstyle="round,pad=0.2", facecolor="#ffffff20", edgecolor=ENTRY_COLOR, linewidth=0.5),
    )

    # Stop Loss
    ax.axhline(signal.stop_loss, color=SL_COLOR, **line_cfg)
    ax.text(
        x_max + 0.3,
        signal.stop_loss,
        f"  SL {_fmt(signal.stop_loss)}\n  ROI: {signal.roi_sl}%",
        color=SL_COLOR,
        fontsize=8,
        fontweight="bold",
        va="center",
        ha="left",
        bbox=dict(boxstyle="round,pad=0.2", facecolor="#ff174420", edgecolor=SL_COLOR, linewidth=0.5),
    )

    # TP1
    ax.axhline(signal.take_profit_1, color=TP_COLOR, **line_cfg)
    ax.text(
        x_max + 0.3,
        signal.take_profit_1,
        f"  TP1 {_fmt(signal.take_profit_1)}\n  ROI: +{signal.roi_tp1}%",
        color=TP_COLOR,
        fontsize=8,
        fontweight="bold",
        va="center",
        ha="left",
        bbox=dict(boxstyle="round,pad=0.2", facecolor="#00c85320", edgecolor=TP_COLOR, linewidth=0.5),
    )

    # TP2
    ax.axhline(signal.take_profit_2, color=TP2_COLOR, **line_cfg)
    ax.text(
        x_max + 0.3,
        signal.take_profit_2,
        f"  TP2 {_fmt(signal.take_profit_2)}\n  ROI: +{signal.roi_tp2}%",
        color=TP2_COLOR,
        fontsize=8,
        fontweight="bold",
        va="center",
        ha="left",
        bbox=dict(boxstyle="round,pad=0.2", facecolor="#00e67620", edgecolor=TP2_COLOR, linewidth=0.5),
    )

    # TP Liq (if available)
    if signal.take_profit_liq is not None:
        ax.axhline(signal.take_profit_liq, color=LIQ_COLOR, linewidth=1, linestyle=":")
        roi_liq = signal.roi_tp_liq
        ax.text(
            x_max + 0.3,
            signal.take_profit_liq,
            f"  TP Liq {_fmt(signal.take_profit_liq)}\n  ROI: +{roi_liq}%",
            color=LIQ_COLOR,
            fontsize=7,
            va="center",
            ha="left",
        )

    # Liquidation price
    liq_price = signal.liquidation_price
    if liq_price is not None:
        ax.axhline(liq_price, color="#ff5252", linewidth=0.8, linestyle=":", alpha=0.6)
        ax.text(
            x_max + 0.3,
            liq_price,
            f"  LIQ {_fmt(liq_price)}",
            color="#ff5252",
            fontsize=7,
            va="center",
            ha="left",
            alpha=0.7,
        )

    # ── Title ──
    emoji = "🟢" if signal.direction == SignalDirection.LONG else "🔴"
    title = (
        f"{signal.direction.value}  {signal.display_symbol}  |  "
        f"x{signal.leverage}  |  RR {signal.rr_ratio}  |  {signal.confidence}"
    )
    ax.set_title(
        title,
        color=GREEN if signal.direction == SignalDirection.LONG else RED,
        fontsize=13,
        fontweight="bold",
        pad=12,
    )

    # ── Adjust x limits for labels ──
    ax.set_xlim(x_min, x_max + 8)

    # ── Render to bytes ──
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight", facecolor=DARK_BG)
    plt.close(fig)
    buf.seek(0)
    return buf.read()


def _fmt(price: float) -> str:
    """Smart price formatting."""
    if price >= 1000:
        return f"{price:,.2f}"
    elif price >= 1:
        return f"{price:,.4f}"
    else:
        return f"{price:.6f}"
